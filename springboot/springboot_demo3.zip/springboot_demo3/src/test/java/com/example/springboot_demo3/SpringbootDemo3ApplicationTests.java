package com.example.springboot_demo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDemo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
