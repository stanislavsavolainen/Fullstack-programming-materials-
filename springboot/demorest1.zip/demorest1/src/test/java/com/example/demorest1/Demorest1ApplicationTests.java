package com.example.demorest1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demorest1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
